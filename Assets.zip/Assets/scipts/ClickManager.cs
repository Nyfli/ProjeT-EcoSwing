using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class ClickManager : MonoBehaviour
{
    public bool _canClick = false;
    [SerializeField] private GameObject _moneyGameObject;
    private Image _moneyImage;
    public UnityEvent onClick;


    private MoneyManager _moneyManager; // R�f�rence � MoneyManager

    // Start is called before the first frame update
    void Start()
    {
        _moneyManager = MoneyManager.instance; // Assigner l'instance de MoneyManager
        StartCoroutine(ClickPermissionRoutine());
    }

    private IEnumerator ClickPermissionRoutine()
    {
        while (true) // Boucle infinie
        {
            yield return new WaitForSeconds(1);
            if (Random.value < 0.1f)
            {
                _canClick = true; // Permettre le clic
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (_canClick)
        {
            // Assombrir l'image en r�duisant sa couleur alpha
            SetImageAlpha(_moneyImage, 0.5f); // 0.5f pour 50% d'opacit�
        }
        else
        {
            // R�tablir l'opacit� de l'image
            SetImageAlpha(_moneyImage, 1f); // 1f pour 100% d'opacit�
        }
    }

    private void Awake()
    {
        _moneyImage = _moneyGameObject.GetComponent<Image>();
    }

    private void SetImageAlpha(Image image, float alpha)
    {
        Color tempColor = image.color;
        tempColor.a = alpha;
        image.color = tempColor;
    }

    public void OnMoneyClicked()
    {
        if (_canClick) // V�rifier si le clic est permis
        {
            _moneyManager.IncreaseMoney();
            _canClick = false;

        }
    }


}
