using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Money Per Second", menuName = "Money Upgrade/Money Per Second")]
public class MoneyUpgradePerSecond : MoneyUpgrade
{
    public override void ApplyUpgrade()
    {
        GameObject go = Instantiate(MoneyManager.instance.MoneyPerSecondObjToSpawn, Vector3.zero, Quaternion.identity);
        go.GetComponent<MoneyPerSecondTimer>().MoneyPerSecond = UpgradeAmount;

        MoneyManager.instance.SimpleMoneyPerSecondIncrease(UpgradeAmount);
    }
}
