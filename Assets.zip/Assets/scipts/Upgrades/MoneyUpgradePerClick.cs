using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "Money Per Click", menuName = "Money Upgrade/Money Per Click")]
public class MoneyUpgradePerClick : MoneyUpgrade
{
    public override void ApplyUpgrade()
    {
        MoneyManager.instance.MoneyPerClickUpgrade += UpgradeAmount;
    }
}
