using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoneyPerSecondTimer : MonoBehaviour
{
    public float timerDuration = 1f;

    public double MoneyPerSecond { get; set; }

    private float _counter;

    private void Update()
    {
        _counter += Time.deltaTime;

        if (_counter >= timerDuration)
        {
            MoneyManager.instance.SimpleMoneyIncrease(MoneyPerSecond);

            _counter = 0;
        }
    }
}
