using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class MoneyManager : MonoBehaviour
{
    public static MoneyManager instance;

    public GameObject MainGameCanvas;
    [SerializeField] private GameObject _upgradeCanvas;
    [SerializeField] private TextMeshProUGUI _moneyCountText;
    [SerializeField] private TextMeshProUGUI _moneyPerSecondText;
    [SerializeField] private GameObject _moneyObj;
    public GameObject moneyTextPopup;
    [SerializeField] private GameObject _backgroundObj;

    [Space]
    public MoneyUpgrade[] MoneyUpgrades;
    [SerializeField] private GameObject _upgradeUIToSpawn;
    [SerializeField] private Transform _upgradeUIParent;
    public GameObject MoneyPerSecondObjToSpawn;

    public double CurrentMoneyCount { get; set; }
    public double CurrentMoneyPerSecond { get; set; }

    //Upgrade
    public double MoneyPerClickUpgrade { get; set; }

    private InitializeUpgrades _initializeUpgrades;
    private ClickManager _clickManager;


    private void Start()
    {

    }


    private void Update()
    {

    }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        UpdateMoneyUI();
        UpdateMoneyPerSecondUI();

        _upgradeCanvas.SetActive(false);
        MainGameCanvas.SetActive(true);

        _initializeUpgrades = GetComponent<InitializeUpgrades>();
        _initializeUpgrades.Initialize(MoneyUpgrades, _upgradeUIToSpawn, _upgradeUIParent);

    }



    #region On Money Click



    public void IncreaseMoney()
    {
        CurrentMoneyCount += 1 + MoneyPerClickUpgrade;
        UpdateMoneyUI();
    }

    #endregion

    #region UI Updates

    private void UpdateMoneyUI()
    {
        _moneyCountText.text = CurrentMoneyCount.ToString();
    }

    private void UpdateMoneyPerSecondUI()
    {
        _moneyPerSecondText.text = CurrentMoneyPerSecond.ToString() + " P/S";
    }

    #endregion

    #region Button Presses

    public void OnUpgradeButtonPress()
    {
        _upgradeCanvas.SetActive(true);
        MainGameCanvas.SetActive(false);
    }

    public void OnResumeButtonPress()
    {
        _upgradeCanvas.SetActive(false);
        MainGameCanvas.SetActive(true);
    }

    #endregion

    #region Simple Increases

    public void SimpleMoneyIncrease(double amount)
    {
        CurrentMoneyCount += amount;
        UpdateMoneyUI();
    }

    public void SimpleMoneyPerSecondIncrease(double amount)
    {
        CurrentMoneyPerSecond += amount;
        UpdateMoneyPerSecondUI();
    }

    #endregion

    #region Events

    public void OnUpgradeButtonClick(MoneyUpgrade upgrade, UpgradeButtonReferences buttonRef)
    {
        if (CurrentMoneyCount >= upgrade.CurrentUpgradeCost)
        {
            upgrade.ApplyUpgrade();
            CurrentMoneyCount -= upgrade.CurrentUpgradeCost;
            UpdateMoneyUI();

            upgrade.CurrentUpgradeCost = Mathf.Round((float)(upgrade.CurrentUpgradeCost * (1 + upgrade.CostIncreaseMultiplierPerPurchase)));

            buttonRef.UpgradeCostText.text = "Cost: " + upgrade.CurrentUpgradeCost;

            // R�activer le clic apr�s l'achat de la mise � niveau
            ReactivateClick();
        }
    }


    public void ReactivateClick()
    {
        _clickManager._canClick = true; // R�activer le clic
    }


    #endregion
}
