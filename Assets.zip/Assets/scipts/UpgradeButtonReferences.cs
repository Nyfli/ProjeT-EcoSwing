using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class UpgradeButtonReferences : MonoBehaviour
{
    public Button UpgradeButton;
    public TextMeshProUGUI UpgradeButtonText;
    public TextMeshProUGUI UpgradeDescriptionText;
    public TextMeshProUGUI UpgradeCostText;


}
